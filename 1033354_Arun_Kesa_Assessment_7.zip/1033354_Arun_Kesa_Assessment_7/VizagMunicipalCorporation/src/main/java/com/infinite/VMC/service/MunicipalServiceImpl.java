package com.infinite.VMC.service;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import com.infinite.VMC.model.Municipal;
import com.infinite.VMC.repository.MunicipalDAOImpl;

public class MunicipalServiceImpl implements IMunicipalService {

	@Autowired
	MunicipalDAOImpl MunicipalDAOImpl;

	@Transactional
	public List<Municipal> getAllComplains() {
		// TODO Auto-generated method stub

		return MunicipalDAOImpl.getAllComplains();
	}

	@Transactional
	public Municipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		return MunicipalDAOImpl.getMunicipal(id);
	}

	@Transactional
	public Municipal addMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		return MunicipalDAOImpl.addMunicipal(municipal);
	}

	@Transactional
	public void updateMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		MunicipalDAOImpl.updateMunicipal(municipal);
	}

	@Transactional
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		MunicipalDAOImpl.deleteMunicipal(id);
	}

}
